# Personal Expense Tracker

A simple full-stack app to track daily expenses.

## Tech Used
- Frontend: React
- Backend: Node.js + Express
- Database: SQLite

## How to Run

### Backend
```
cd backend
npm install
npm start
```

### Frontend
```
cd frontend
npm install
npm run dev
```

Open http://localhost:5173 in your browser.

## Features
- Add new expense
- View all expenses
- Edit an expense
- Delete an expense
- See total spending

## API Endpoints
- POST /api/expenses - add expense
- GET /api/expenses - get all expenses
- GET /api/expenses/:id - get one expense
- PUT /api/expenses/:id - update expense
- DELETE /api/expenses/:id - delete expense
