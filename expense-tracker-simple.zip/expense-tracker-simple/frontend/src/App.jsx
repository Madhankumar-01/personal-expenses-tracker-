import { useState, useEffect } from 'react';

const API = 'http://localhost:5000/api/expenses';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Food');
  const [date, setDate] = useState('');
  const [notes, setNotes] = useState('');
  const [editId, setEditId] = useState(null);

  // Load all expenses when page opens
  useEffect(() => {
    loadExpenses();
  }, []);

  function loadExpenses() {
    fetch(API)
      .then(res => res.json())
      .then(data => setExpenses(data));
  }

  function clearForm() {
    setTitle('');
    setAmount('');
    setCategory('Food');
    setDate('');
    setNotes('');
    setEditId(null);
  }

  function handleSubmit(e) {
    e.preventDefault();

    const expenseData = { title, amount: Number(amount), category, date, notes };

    if (editId) {
      // Update existing expense
      fetch(`${API}/${editId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expenseData)
      }).then(() => {
        loadExpenses();
        clearForm();
      });
    } else {
      // Create new expense
      fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expenseData)
      }).then(() => {
        loadExpenses();
        clearForm();
      });
    }
  }

  function handleEdit(expense) {
    setTitle(expense.title);
    setAmount(expense.amount);
    setCategory(expense.category);
    setDate(expense.date);
    setNotes(expense.notes);
    setEditId(expense.id);
  }

  function handleDelete(id) {
    if (window.confirm('Delete this expense?')) {
      fetch(`${API}/${id}`, { method: 'DELETE' })
        .then(() => loadExpenses());
    }
  }

  const total = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="app">
      <h1>💰 Expense Tracker</h1>

      <form onSubmit={handleSubmit} className="expense-form">
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={e => setTitle(e.target.value)}
          required
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          required
        />
        <select value={category} onChange={e => setCategory(e.target.value)}>
          <option>Food</option>
          <option>Transport</option>
          <option>Housing</option>
          <option>Entertainment</option>
          <option>Other</option>
        </select>
        <input
          type="date"
          value={date}
          onChange={e => setDate(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Notes (optional)"
          value={notes}
          onChange={e => setNotes(e.target.value)}
        />
        <button type="submit">{editId ? 'Update' : 'Add'} Expense</button>
        {editId && <button type="button" onClick={clearForm}>Cancel</button>}
      </form>

      <h2>Total: ${total.toFixed(2)}</h2>

      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Notes</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {expenses.map(exp => (
            <tr key={exp.id}>
              <td>{exp.title}</td>
              <td>{exp.category}</td>
              <td>{exp.date}</td>
              <td>${exp.amount.toFixed(2)}</td>
              <td>{exp.notes}</td>
              <td>
                <button onClick={() => handleEdit(exp)}>Edit</button>
                <button onClick={() => handleDelete(exp.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
