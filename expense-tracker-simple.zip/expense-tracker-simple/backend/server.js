const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Setup database
const db = new Database('expenses.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    amount REAL NOT NULL,
    category TEXT NOT NULL,
    date TEXT NOT NULL,
    notes TEXT
  )
`);

// CREATE - Add new expense
app.post('/api/expenses', (req, res) => {
  const { title, amount, category, date, notes } = req.body;

  if (!title || !amount || !category || !date) {
    return res.status(400).json({ error: 'Please fill all required fields' });
  }
  if (amount <= 0) {
    return res.status(400).json({ error: 'Amount must be more than 0' });
  }

  const stmt = db.prepare('INSERT INTO expenses (title, amount, category, date, notes) VALUES (?, ?, ?, ?, ?)');
  const result = stmt.run(title, amount, category, date, notes || '');

  const newExpense = db.prepare('SELECT * FROM expenses WHERE id = ?').get(result.lastInsertRowid);
  res.json(newExpense);
});

// READ - Get all expenses
app.get('/api/expenses', (req, res) => {
  const expenses = db.prepare('SELECT * FROM expenses ORDER BY date DESC').all();
  res.json(expenses);
});

// READ - Get one expense
app.get('/api/expenses/:id', (req, res) => {
  const expense = db.prepare('SELECT * FROM expenses WHERE id = ?').get(req.params.id);

  if (!expense) {
    return res.status(404).json({ error: 'Expense not found' });
  }
  res.json(expense);
});

// UPDATE - Edit an expense
app.put('/api/expenses/:id', (req, res) => {
  const { title, amount, category, date, notes } = req.body;
  const id = req.params.id;

  const existing = db.prepare('SELECT * FROM expenses WHERE id = ?').get(id);
  if (!existing) {
    return res.status(404).json({ error: 'Expense not found' });
  }

  db.prepare('UPDATE expenses SET title=?, amount=?, category=?, date=?, notes=? WHERE id=?')
    .run(title, amount, category, date, notes, id);

  const updated = db.prepare('SELECT * FROM expenses WHERE id = ?').get(id);
  res.json(updated);
});

// DELETE - Remove an expense
app.delete('/api/expenses/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM expenses WHERE id = ?').get(req.params.id);
  if (!existing) {
    return res.status(404).json({ error: 'Expense not found' });
  }

  db.prepare('DELETE FROM expenses WHERE id = ?').run(req.params.id);
  res.json({ message: 'Deleted successfully' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
